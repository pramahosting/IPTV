from prama_dashboard_agent.app import main

if __name__ == "__main__":
    main()